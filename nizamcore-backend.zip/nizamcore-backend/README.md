# NizamCore — Backend API

Backend Sistem Informasi Akademik dibangun dengan **Clean Architecture** menggunakan **Express.js**, **Drizzle ORM**, **PostgreSQL**, dan **JWT**.

---

## 🛠️ Tech Stack

| Komponen       | Teknologi          |
|----------------|--------------------|
| Runtime        | Node.js v18+       |
| Framework      | Express.js         |
| Database       | PostgreSQL v14+    |
| ORM            | Drizzle ORM        |
| Autentikasi    | JWT (jsonwebtoken) |
| Password Hash  | bcryptjs           |
| Language       | TypeScript         |

---

## 🏗️ Arsitektur: Clean Architecture

```
src/
├── index.ts                                  # Entry point server
├── db/
│   ├── index.ts                              # Koneksi database
│   ├── migrate.ts                            # Script migrasi
│   ├── seed.ts                               # Script seeder
│   ├── migrations/                           # File SQL migrasi
│   └── schema/
│       ├── users.schema.ts                   # Tabel users
│       ├── mata-kuliah.schema.ts             # Tabel mata_kuliah
│       └── index.ts                          # Re-export skema
├── common/
│   └── types/
│       └── index.ts                          # Shared types & helper response
├── middlewares/
│   └── auth.middleware.ts                    # authenticate + dosenOnly
└── modules/
    ├── auth/
    │   ├── auth.repository.ts                # [DATA]     Query user di DB
    │   ├── auth.service.ts                   # [BUSINESS] Logika login & JWT
    │   └── auth.controller.ts                # [HTTP]     Route POST /auth/login
    └── mata-kuliah/
        ├── mata-kuliah.repository.ts         # [DATA]     CRUD query DB
        ├── mata-kuliah.service.ts            # [BUSINESS] Validasi & rules
        └── mata-kuliah.controller.ts         # [HTTP]     Semua route /mata-kuliah
```

### Alur Request
```
HTTP Request
    ↓
Controller  → terima request, parsing body
    ↓
Middleware  → verifikasi JWT, cek role
    ↓
Service     → validasi bisnis (kode unik, SKS 1-6, dll.)
    ↓
Repository  → eksekusi query via Drizzle ORM
    ↓
PostgreSQL
```

---

## 🗄️ Skema Database

### Tabel `users`
| Kolom           | Tipe         | Keterangan                    |
|-----------------|--------------|-------------------------------|
| `id`            | UUID         | Primary key, auto-generate    |
| `username`      | VARCHAR(100) | Unik, tidak boleh kosong      |
| `password_hash` | VARCHAR(255) | Hash bcrypt dari password     |
| `role`          | ENUM         | Nilai: `'Dosen'`/`'Mahasiswa'`|
| `created_at`    | TIMESTAMP    | Waktu dibuat, default `NOW()` |

### Tabel `mata_kuliah`
| Kolom        | Tipe         | Keterangan                  |
|--------------|--------------|-----------------------------|
| `id`         | UUID         | Primary key, auto-generate  |
| `nama`       | VARCHAR(200) | Nama mata kuliah            |
| `kode`       | VARCHAR(20)  | Kode unik (contoh: TIF101)  |
| `bobot_sks`  | INTEGER      | Jumlah SKS (valid: 1–6)     |
| `created_at` | TIMESTAMP    | Waktu dibuat                |
| `updated_at` | TIMESTAMP    | Waktu terakhir diperbarui   |

---

## 🔐 Autentikasi & Otorisasi

### Alur JWT
1. `POST /auth/login` → server memverifikasi kredensial
2. Server menerbitkan JWT berisi `{ userId, username, role }`
3. Client menyimpan token dan menyertakannya di setiap request:
   ```
   Authorization: Bearer <token>
   ```
4. Middleware `authenticate` memverifikasi token
5. Middleware `dosenOnly` mengecek role sebelum akses handler

### Matrix Akses
| Endpoint                | Mahasiswa | Dosen |
|-------------------------|-----------|-------|
| `POST /auth/login`      | ✅        | ✅    |
| `GET /mata-kuliah`      | ✅        | ✅    |
| `GET /mata-kuliah/:id`  | ✅        | ✅    |
| `POST /mata-kuliah`     | ❌ 403    | ✅    |
| `PATCH /mata-kuliah/:id`| ❌ 403    | ✅    |
| `DELETE /mata-kuliah/:id`| ❌ 403   | ✅    |

---

## 🚀 Cara Menjalankan di Lokal

### Prasyarat
- **Node.js** v18+ → [nodejs.org](https://nodejs.org)
- **PostgreSQL** v14+ (aktif berjalan)
- **Git**

### Langkah 1 — Clone & Install
```bash
git clone https://github.com/fanrmdhan/nizam-core.git
cd nizam-core
npm install
```

### Langkah 2 — Konfigurasi Environment
```bash
# Windows
copy .env.example .env

# Mac / Linux
cp .env.example .env
```

Edit file `.env`:
```env
DATABASE_URL=postgres://postgres:PASSWORD_KAMU@localhost:5432/nizamcore
JWT_SECRET=ganti_dengan_string_panjang_acak_minimal_32_karakter
JWT_EXPIRES_IN=7d
PORT=3000
NODE_ENV=development
```

### Langkah 3 — Buat Database
```bash
# Via psql terminal
psql -U postgres -c "CREATE DATABASE nizamcore;"
```
Atau buka **pgAdmin** → klik kanan Databases → Create → Database → isi nama `nizamcore`.

### Langkah 4 — Migrasi & Seed
```bash
# Generate file SQL dari skema Drizzle
npm run db:generate

# Jalankan migrasi ke database
npm run db:migrate

# Isi data awal
npm run db:seed
```

### Langkah 5 — Jalankan Server
```bash
# Development (auto-restart)
npm run dev

# Production
npm run build && npm run start
```

Server berjalan di: **`http://localhost:3000`**

---

## 👤 Akun Demo (setelah seed)

| Username        | Password      | Role       |
|-----------------|---------------|------------|
| `dosen_nizam`   | `password123` | Dosen      |
| `mahasiswa_ali` | `password123` | Mahasiswa  |

---

## 📋 Dokumentasi Endpoint

### `POST /auth/login`
```json
// Request
{ "username": "dosen_nizam", "password": "password123" }

// Response 200
{
  "success": true,
  "message": "Login berhasil.",
  "data": {
    "token": "eyJhbGci...",
    "user": { "userId": "uuid", "username": "dosen_nizam", "role": "Dosen" }
  }
}
```

### `GET /mata-kuliah`
```bash
curl http://localhost:3000/mata-kuliah \
  -H "Authorization: Bearer <TOKEN>"
```

### `POST /mata-kuliah` *(Dosen only)*
```json
{ "nama": "Pemrograman Web", "kode": "TIF303", "bobotSks": 3 }
```

### `PATCH /mata-kuliah/:id` *(Dosen only)*
```json
{ "bobotSks": 4 }
```

### `DELETE /mata-kuliah/:id` *(Dosen only)*
```bash
curl -X DELETE http://localhost:3000/mata-kuliah/<id> \
  -H "Authorization: Bearer <TOKEN_DOSEN>"
```

---

## 📦 Perintah Tersedia

| Perintah           | Fungsi                                     |
|--------------------|--------------------------------------------|
| `npm run dev`      | Jalankan server development (hot-reload)   |
| `npm run build`    | Compile TypeScript → JavaScript            |
| `npm run start`    | Jalankan server production                 |
| `npm run db:generate` | Generate file migrasi SQL dari skema    |
| `npm run db:migrate`  | Jalankan migrasi ke database            |
| `npm run db:seed`     | Isi data awal (users & mata kuliah)     |
| `npm run db:studio`   | Buka Drizzle Studio (GUI database)      |
