import { Response } from "express";

export interface ApiResponse<T = null> {
  success: boolean;
  message: string;
  data?: T;
  errors?: Record<string, string>;
}

export interface JwtPayload {
  userId: string;
  username: string;
  role: "Dosen" | "Mahasiswa";
}

export const sendSuccess = <T>(
  res: Response,
  message: string,
  data?: T,
  statusCode = 200
): Response => {
  return res.status(statusCode).json({ success: true, message, data });
};

export const sendError = (
  res: Response,
  message: string,
  statusCode = 400,
  errors?: Record<string, string>
): Response => {
  return res.status(statusCode).json({ success: false, message, ...(errors && { errors }) });
};
