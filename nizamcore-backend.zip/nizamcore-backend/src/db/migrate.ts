import { migrate } from "drizzle-orm/postgres-js/migrator";
import postgres from "postgres";
import { drizzle } from "drizzle-orm/postgres-js";
import * as dotenv from "dotenv";
import path from "path";

dotenv.config();

async function runMigrations() {
  const connectionString = process.env.DATABASE_URL!;
  const client = postgres(connectionString, { max: 1 });
  const db = drizzle(client);

  console.log("⏳ Menjalankan migrasi database...");

  await migrate(db, {
    migrationsFolder: path.join(__dirname, "migrations"),
  });

  console.log("✅ Migrasi selesai!");
  await client.end();
  process.exit(0);
}

runMigrations().catch((err) => {
  console.error("❌ Migrasi gagal:", err);
  process.exit(1);
});
