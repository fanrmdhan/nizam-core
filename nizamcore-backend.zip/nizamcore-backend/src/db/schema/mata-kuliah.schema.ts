import { pgTable, uuid, varchar, integer, timestamp } from "drizzle-orm/pg-core";

export const mataKuliah = pgTable("mata_kuliah", {
  id: uuid("id").primaryKey().defaultRandom(),
  nama: varchar("nama", { length: 200 }).notNull(),
  kode: varchar("kode", { length: 20 }).notNull().unique(),
  bobotSks: integer("bobot_sks").notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
});

export type MataKuliah = typeof mataKuliah.$inferSelect;
export type NewMataKuliah = typeof mataKuliah.$inferInsert;
