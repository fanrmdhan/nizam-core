import { db } from "./index";
import { users, mataKuliah } from "./schema";
import bcrypt from "bcryptjs";
import * as dotenv from "dotenv";

dotenv.config();

async function seed() {
  console.log("🌱 Memulai seeding database...");

  // Seed users
  const hashedPassword = await bcrypt.hash("password123", 12);

  await db.insert(users).values([
    {
      username: "dosen_nizam",
      passwordHash: hashedPassword,
      role: "Dosen",
    },
    {
      username: "mahasiswa_ali",
      passwordHash: hashedPassword,
      role: "Mahasiswa",
    },
  ]).onConflictDoNothing();

  console.log("✅ Users seeded: dosen_nizam, mahasiswa_ali (password: password123)");

  // Seed mata kuliah
  await db.insert(mataKuliah).values([
    { nama: "Algoritma & Pemrograman", kode: "TIF101", bobotSks: 3 },
    { nama: "Kalkulus I", kode: "MAT101", bobotSks: 4 },
    { nama: "Basis Data", kode: "TIF202", bobotSks: 3 },
    { nama: "Rekayasa Perangkat Lunak", kode: "TIF301", bobotSks: 3 },
    { nama: "Jaringan Komputer", kode: "TIF302", bobotSks: 3 },
    { nama: "Kecerdasan Buatan", kode: "TIF401", bobotSks: 3 },
    { nama: "Pemrograman Web", kode: "TIF303", bobotSks: 3 },
    { nama: "Sistem Operasi", kode: "TIF304", bobotSks: 3 },
  ]).onConflictDoNothing();

  console.log("✅ Mata kuliah seeded: 8 data");
  console.log("🎉 Seeding selesai!");
  process.exit(0);
}

seed().catch((err) => {
  console.error("❌ Seeding gagal:", err);
  process.exit(1);
});
