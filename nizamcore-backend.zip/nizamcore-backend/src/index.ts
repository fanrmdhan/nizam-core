import express, { Request, Response, NextFunction } from "express";
import cors from "cors";
import helmet from "helmet";
import * as dotenv from "dotenv";

import authRouter from "./modules/auth/auth.controller";
import mataKuliahRouter from "./modules/mata-kuliah/mata-kuliah.controller";

dotenv.config();

const app = express();
const PORT = process.env.PORT ?? 3000;

// ─── Middleware Global ───────────────────────────────────────────
app.use(helmet());
app.use(cors());
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

// ─── Health Check ────────────────────────────────────────────────
app.get("/", (_req: Request, res: Response) => {
  res.json({
    success: true,
    message: "NizamCore API berjalan ✅",
    version: "1.0.0",
    timestamp: new Date().toISOString(),
  });
});

// ─── Routes ──────────────────────────────────────────────────────
app.use("/auth", authRouter);
app.use("/mata-kuliah", mataKuliahRouter);

// ─── 404 Handler ─────────────────────────────────────────────────
app.use((_req: Request, res: Response) => {
  res.status(404).json({
    success: false,
    message: "Endpoint tidak ditemukan.",
  });
});

// ─── Global Error Handler ─────────────────────────────────────────
app.use((err: Error, _req: Request, res: Response, _next: NextFunction) => {
  console.error("❌ Unhandled error:", err.stack);
  res.status(500).json({
    success: false,
    message: "Terjadi kesalahan internal server.",
  });
});

// ─── Start Server ────────────────────────────────────────────────
app.listen(PORT, () => {
  console.log(`🚀 NizamCore API berjalan di http://localhost:${PORT}`);
  console.log(`📦 Environment : ${process.env.NODE_ENV ?? "development"}`);
  console.log(`🗄️  Database   : ${process.env.DATABASE_URL?.split("@")[1] ?? "tidak dikonfigurasi"}`);
});
