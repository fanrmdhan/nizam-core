import { Request, Response, NextFunction } from "express";
import jwt from "jsonwebtoken";
import { JwtPayload, sendError } from "../common/types";

// Extend Express Request agar mengenal properti `user`
declare global {
  namespace Express {
    interface Request {
      user?: JwtPayload;
    }
  }
}

/**
 * Middleware: Verifikasi JWT dari header Authorization
 * Menyimpan payload ke req.user jika valid
 */
export const authenticate = (
  req: Request,
  res: Response,
  next: NextFunction
): void => {
  const authHeader = req.headers.authorization;

  if (!authHeader?.startsWith("Bearer ")) {
    sendError(res, "Token tidak ditemukan. Silakan login terlebih dahulu.", 401);
    return;
  }

  const token = authHeader.split(" ")[1];

  try {
    const decoded = jwt.verify(token, process.env.JWT_SECRET!) as JwtPayload;
    req.user = decoded;
    next();
  } catch {
    sendError(res, "Token tidak valid atau sudah kedaluwarsa.", 401);
  }
};

/**
 * Middleware: Hanya izinkan role Dosen
 * Harus dipakai SETELAH authenticate
 */
export const dosenOnly = (
  req: Request,
  res: Response,
  next: NextFunction
): void => {
  if (req.user?.role !== "Dosen") {
    sendError(
      res,
      "Akses ditolak. Fitur ini hanya dapat digunakan oleh Dosen.",
      403
    );
    return;
  }
  next();
};
