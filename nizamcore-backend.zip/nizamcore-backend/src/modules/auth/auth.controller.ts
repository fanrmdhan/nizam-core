import { Router, Request, Response } from "express";
import { AuthService } from "./auth.service";
import { sendSuccess, sendError } from "../../common/types";

const router = Router();
const authService = new AuthService();

/**
 * POST /auth/login
 * Body: { username: string, password: string }
 */
router.post("/login", async (req: Request, res: Response): Promise<void> => {
  try {
    const result = await authService.login(req.body);
    sendSuccess(res, "Login berhasil.", result);
  } catch (err) {
    const message =
      err instanceof Error ? err.message : "Terjadi kesalahan server.";
    sendError(res, message, 401);
  }
});

export default router;
