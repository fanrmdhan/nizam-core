import bcrypt from "bcryptjs";
import jwt from "jsonwebtoken";
import { AuthRepository } from "./auth.repository";
import { JwtPayload } from "../../common/types";

interface LoginDto {
  username: string;
  password: string;
}

interface LoginResult {
  token: string;
  user: JwtPayload;
}

export class AuthService {
  constructor(private readonly repo = new AuthRepository()) {}

  async login(dto: LoginDto): Promise<LoginResult> {
    // Validasi input
    if (!dto.username?.trim()) {
      throw new Error("Username wajib diisi.");
    }
    if (!dto.password) {
      throw new Error("Password wajib diisi.");
    }

    // Cari user di database
    const user = await this.repo.findByUsername(dto.username.trim());

    // Pesan error sama untuk username/password salah (keamanan: hindari user enumeration)
    if (!user) {
      throw new Error("Username atau password salah.");
    }

    // Verifikasi password dengan bcrypt
    const isValid = await bcrypt.compare(dto.password, user.passwordHash);
    if (!isValid) {
      throw new Error("Username atau password salah.");
    }

    // Buat JWT payload
    const payload: JwtPayload = {
      userId: user.id,
      username: user.username,
      role: user.role,
    };

    const token = jwt.sign(payload, process.env.JWT_SECRET!, {
      expiresIn: (process.env.JWT_EXPIRES_IN ?? "7d") as string,
    } as jwt.SignOptions);

    return { token, user: payload };
  }
}
