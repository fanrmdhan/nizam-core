import { Router, Request, Response } from "express";
import { MataKuliahService } from "./mata-kuliah.service";
import { authenticate, dosenOnly } from "../../middlewares/auth.middleware";
import { sendSuccess, sendError } from "../../common/types";

const router = Router();
const service = new MataKuliahService();

/**
 * GET /mata-kuliah
 * Akses: Dosen & Mahasiswa (authenticate)
 */
router.get("/", authenticate, async (_req: Request, res: Response): Promise<void> => {
  try {
    const data = await service.findAll();
    sendSuccess(res, "Berhasil mengambil daftar mata kuliah.", data);
  } catch {
    sendError(res, "Terjadi kesalahan server.", 500);
  }
});

/**
 * GET /mata-kuliah/:id
 * Akses: Dosen & Mahasiswa (authenticate)
 */
router.get("/:id", authenticate, async (req: Request, res: Response): Promise<void> => {
  try {
    const data = await service.findById(req.params.id as string);
    sendSuccess(res, "Berhasil mengambil detail mata kuliah.", data);
  } catch (err) {
    const message = err instanceof Error ? err.message : "Terjadi kesalahan server.";
    const status = message.includes("tidak ditemukan") ? 404 : 500;
    sendError(res, message, status);
  }
});

/**
 * POST /mata-kuliah
 * Akses: Dosen only
 * Body: { nama, kode, bobotSks }
 */
router.post("/", authenticate, dosenOnly, async (req: Request, res: Response): Promise<void> => {
  try {
    const data = await service.create(req.body);
    sendSuccess(res, "Mata kuliah berhasil ditambahkan.", data, 201);
  } catch (err) {
    const message = err instanceof Error ? err.message : "Terjadi kesalahan server.";
    sendError(res, message, 400);
  }
});

/**
 * PATCH /mata-kuliah/:id
 * Akses: Dosen only
 * Body: { nama?, kode?, bobotSks? } — semua field opsional
 */
router.patch("/:id", authenticate, dosenOnly, async (req: Request, res: Response): Promise<void> => {
  try {
    const data = await service.update(req.params.id as string, req.body);
    sendSuccess(res, "Mata kuliah berhasil diperbarui.", data);
  } catch (err) {
    const message = err instanceof Error ? err.message : "Terjadi kesalahan server.";
    const status = message.includes("tidak ditemukan") ? 404 : 400;
    sendError(res, message, status);
  }
});

/**
 * DELETE /mata-kuliah/:id
 * Akses: Dosen only
 */
router.delete("/:id", authenticate, dosenOnly, async (req: Request, res: Response): Promise<void> => {
  try {
    await service.delete(req.params.id as string);
    sendSuccess(res, "Mata kuliah berhasil dihapus.");
  } catch (err) {
    const message = err instanceof Error ? err.message : "Terjadi kesalahan server.";
    const status = message.includes("tidak ditemukan") ? 404 : 500;
    sendError(res, message, status);
  }
});

export default router;
