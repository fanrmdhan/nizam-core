import { MataKuliahRepository } from "./mata-kuliah.repository";
import { MataKuliah } from "../../db/schema";

interface CreateMataKuliahDto {
  nama: string;
  kode: string;
  bobotSks: number;
}

type UpdateMataKuliahDto = Partial<CreateMataKuliahDto>;

export class MataKuliahService {
  constructor(private readonly repo = new MataKuliahRepository()) {}

  private validateCreateDto(dto: CreateMataKuliahDto): void {
    if (!dto.nama?.trim()) {
      throw new Error("Nama mata kuliah wajib diisi.");
    }
    if (!dto.kode?.trim()) {
      throw new Error("Kode mata kuliah wajib diisi.");
    }
    if (
      !Number.isInteger(dto.bobotSks) ||
      dto.bobotSks < 1 ||
      dto.bobotSks > 6
    ) {
      throw new Error("Bobot SKS harus berupa angka bulat antara 1 hingga 6.");
    }
  }

  private validateSks(bobotSks: number): void {
    if (!Number.isInteger(bobotSks) || bobotSks < 1 || bobotSks > 6) {
      throw new Error("Bobot SKS harus berupa angka bulat antara 1 hingga 6.");
    }
  }

  async findAll(): Promise<MataKuliah[]> {
    return this.repo.findAll();
  }

  async findById(id: string): Promise<MataKuliah> {
    const mk = await this.repo.findById(id);
    if (!mk) {
      throw new Error("Mata kuliah tidak ditemukan.");
    }
    return mk;
  }

  async create(dto: CreateMataKuliahDto): Promise<MataKuliah> {
    this.validateCreateDto(dto);

    const kodeUpper = dto.kode.trim().toUpperCase();

    // Cek duplikat kode
    const existing = await this.repo.findByKode(kodeUpper);
    if (existing) {
      throw new Error(`Kode mata kuliah '${kodeUpper}' sudah digunakan.`);
    }

    return this.repo.create({
      nama: dto.nama.trim(),
      kode: kodeUpper,
      bobotSks: dto.bobotSks,
    });
  }

  async update(id: string, dto: UpdateMataKuliahDto): Promise<MataKuliah> {
    // Pastikan data ada
    await this.findById(id);

    if (dto.bobotSks !== undefined) {
      this.validateSks(dto.bobotSks);
    }

    if (dto.kode) {
      const kodeUpper = dto.kode.trim().toUpperCase();
      const existing = await this.repo.findByKode(kodeUpper);
      if (existing && existing.id !== id) {
        throw new Error(`Kode mata kuliah '${kodeUpper}' sudah digunakan.`);
      }
      dto.kode = kodeUpper;
    }

    if (dto.nama) {
      dto.nama = dto.nama.trim();
    }

    const updated = await this.repo.update(id, dto);
    return updated!;
  }

  async delete(id: string): Promise<void> {
    await this.findById(id);
    await this.repo.delete(id);
  }
}
